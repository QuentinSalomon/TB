﻿myArray = [<%values%>];
Actualise();